/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.testdata;

import excelUtility.XLs_Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import static javax.management.Query.lt;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

/**
 *
 * @author Reverside
 */
public class tesData {

    /**
     * @param args the command line arguments
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {

        //Setup Chrome driver Property path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Reverside\\Downloads\\chromedriver_win32Update\\chromedriver.exe");

        // Set webDriver
        ChromeDriver driver = new ChromeDriver();

        //Wait for page to load completely
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

        //Navigate to  webtable 
        driver.get("http://www.way2automation.com/angularjs-protractor/webtables/");

        //Read Excel file Values
        XLs_Reader reader = new XLs_Reader("C:\\Users\\Reverside\\Documents\\NetBeansProjects\\testData\\src\\main\\java\\com\\testData\\testData.xlsx");
        int rowCount = reader.getRowCount("Regdata");
        int rowNum;
        String username = "";
        String sValue = "";

        //First Array to store Excel file values  from external file.
        //Second Array to store usernames from  www.way2automation.com -webTables
        List<String> newDataTables = new ArrayList<String>();
        List<String> newDataExcel = new ArrayList<String>();

        //get Usernames from www.way2automation.com -webTables by using For-Loop statement
        for (int i = 1; i <= 5; i++) {
            sValue = driver.findElement(By.xpath("/html/body/table/tbody/tr[" + i + "]/td[3]")).getText();

            //Add each usernames to an Arrary newDataTables from ww.way2automation.com -webTables
            newDataTables.add(sValue);
        }

        //Printout usernames from an array
        System.out.println("Usermaes on the tables");
        System.out.println(newDataTables);

        //get Usernames from Excel file by using For-Loop statement
        for (int j = 2; j < reader.getRowCount("Regdata"); j++) {
            username = reader.getCellData("Regdata", "username", j);

            //Add each usernames to an Arrary from newDataExcel
            newDataExcel.add(username);
        }

        //Printout usernames from an array
        System.out.println("Usermaes on the Excel file");
        System.out.println(newDataExcel);

        //Use if statement to check if each usernames on newDataTables matches with newDataTables
        // or Add new user to the table
        if (newDataTables.equals(newDataTables)) {
            System.out.println(" Username found");

        } else {

            //Add new user
            WebElement link;
            link = driver.findElement(By.cssSelector("body > table > thead > tr:nth-child(2) > td > button"));
            link.click();
            Thread.sleep(10000);
            
            //initialize Excel file sheet name
            rowCount = reader.getRowCount("Regdata");
            
            //Constant values for two Radio buttons
            String company = "Company AAA";
            String companyOne = "Company BBB";
            
            //Use For-Loop to retrive user values from Excel file
            //And store it to actual variable
            for (rowNum = 2; rowNum <= rowCount; rowNum++) {

                //Parameterasation
                String firstName = reader.getCellData("Regdata", "firstname", rowNum);
                System.out.println(firstName);
                String lastName = reader.getCellData("Regdata", "lastname", rowNum);
                System.out.println(lastName);
                String username1 = reader.getCellData("Regdata", "username", rowNum);
                System.out.println(username1);
                String password = reader.getCellData("Regdata", "password", rowNum);
                System.out.println(password);
                String customer = reader.getCellData("Regdata", "customer", rowNum);
                System.out.println(customer);
                String role = reader.getCellData("Regdata", "role", rowNum);
                System.out.println(role);
                String email = reader.getCellData("Regdata", "email", rowNum);
                System.out.println(email);
                String cellphone = reader.getCellData("Regdata", "cellphone", rowNum);
                System.out.println(cellphone);

               //Send values from External file to WebTable.
               //To insert new record ,clear each field.
                
                driver.findElement(By.name("FirstName")).clear();
                driver.findElement(By.name("FirstName")).sendKeys(firstName);

                driver.findElement(By.name("LastName")).clear();
                driver.findElement(By.name("LastName")).sendKeys(lastName);

                driver.findElement(By.name("UserName")).clear();
                driver.findElement(By.name("UserName")).sendKeys(username);

                driver.findElement(By.name("Password")).clear();
                driver.findElement(By.name("Password")).sendKeys(password);

                //If Customer Company from Excel matches Company AAA then click Company AAA radio button
                //If Customer Company from Excel matches Company BBB then click Company BBB radio button
                if (customer.matches(company)) {
                    driver.findElement(By.cssSelector("label.radio:nth-child(1)")).click();

                } else if (customer.matches(companyOne)) {
                    driver.findElement(By.cssSelector("label.radio:nth-child(2)")).click();
                } else {
                    System.out.println("Please select Company");
                }

                //Select values from drop down box based on role ID
                Select selectRole = new Select(driver.findElement(By.name("RoleId")));
                selectRole.selectByVisibleText(role);

                driver.findElement(By.name("Email")).clear();
                driver.findElement(By.name("Email")).sendKeys(email);

                driver.findElement(By.name("Mobilephone")).clear();
                driver.findElement(By.name("Mobilephone")).sendKeys(cellphone);
                driver.findElement(By.cssSelector("body > div.modal.ng-scope > div.modal-footer > button.btn.btn-success")).click();

                //Submit User Details
                link = driver.findElement(By.cssSelector("body > table > thead > tr:nth-child(2) > td > button"));
                link.click();

                Thread.sleep(5000);
                //Click close button to allow new User details to be enter
                driver.findElement(By.cssSelector("body > div.modal.ng-scope > div.modal-footer > button.btn.btn-danger")).click();

            }
        }

    }

}
